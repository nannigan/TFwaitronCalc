// Code goes here
angular.component('test',[ngRoute])
.config(['$routeProvider', function($routeProvider)
    {   
        $routeProvider
        .when('/',
        {
            templateUrl: 'home.html',
            controller: 'HomeCtrl'
        })
        .when('/new-page',
        {
            templateUrl: 'new-page.html',
            controller: 'newPageCtrl'

        })
         .when('/second-page',
        {
            templateUrl: 'second-page.html',
            controller: 'secondPageCtrl'

        });


    }])
    .run(function($rootScope, $location)
    {
        $rootScope.$on('$routeChangeError', function()
        {
            $location.path('/home');
        });
    })
    .controller('HomeCtrl', function($scope){
      $scope.message = 'hey ho';
    })
    .controller('newPageCtrl', function($scope){
      var calc = function(one, two){
        one = $scope.one;
        two = $scope.two;
         var total = one + two;
         return total;
      };
       $scope.total = total;
    })
    .controller('secondPageCtrl', function($scope){
      var halfTotal = function (total){
        return total/2;
      };
      $scope.halfTotal= halfTotal();
    });
    
